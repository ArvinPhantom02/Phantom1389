package com.phantom.aivision.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore("phantom_settings")

data class AppSettings(
    val detectionEnabled: Boolean = false,
    val sensitivity: Float = 0.5f,
    val minSize: Float = 0.05f,       // حداقل ارتفاع کادر نسبت به ارتفاع تصویر
    val magnification: Float = 2f,    // 1x تا 5x
    val magSizeDp: Float = 220f,
    val magAlpha: Float = 0.95f,
    val thermalEnabled: Boolean = false,
    val thermalMode: Int = 0,         // 0 حرارتی، 1 مادون‌قرمز، 2 سیاه‌وسفید، 3 کنتراست
    val thermalIntensity: Float = 0.7f,
    val accentIndex: Int = 0,
    val fontScale: Float = 1f
)

class SettingsRepository(private val context: Context) {
    private object K {
        val det = booleanPreferencesKey("det")
        val sens = floatPreferencesKey("sens")
        val min = floatPreferencesKey("min")
        val mag = floatPreferencesKey("mag")
        val magSize = floatPreferencesKey("magSize")
        val magAlpha = floatPreferencesKey("magAlpha")
        val th = booleanPreferencesKey("th")
        val thMode = intPreferencesKey("thMode")
        val thInt = floatPreferencesKey("thInt")
        val accent = intPreferencesKey("accent")
        val fontScale = floatPreferencesKey("fontScale")
    }

    val settings: Flow<AppSettings> = context.store.data.map { p ->
        val d = AppSettings()
        AppSettings(
            detectionEnabled = p[K.det] ?: d.detectionEnabled,
            sensitivity = p[K.sens] ?: d.sensitivity,
            minSize = p[K.min] ?: d.minSize,
            magnification = p[K.mag] ?: d.magnification,
            magSizeDp = p[K.magSize] ?: d.magSizeDp,
            magAlpha = p[K.magAlpha] ?: d.magAlpha,
            thermalEnabled = p[K.th] ?: d.thermalEnabled,
            thermalMode = p[K.thMode] ?: d.thermalMode,
            thermalIntensity = p[K.thInt] ?: d.thermalIntensity,
            accentIndex = p[K.accent] ?: d.accentIndex,
            fontScale = p[K.fontScale] ?: d.fontScale
        )
    }

    suspend fun setDetection(v: Boolean) = context.store.edit { it[K.det] = v }
    suspend fun setSensitivity(v: Float) = context.store.edit { it[K.sens] = v }
    suspend fun setMinSize(v: Float) = context.store.edit { it[K.min] = v }
    suspend fun setMagnification(v: Float) = context.store.edit { it[K.mag] = v }
    suspend fun setMagSize(v: Float) = context.store.edit { it[K.magSize] = v }
    suspend fun setMagAlpha(v: Float) = context.store.edit { it[K.magAlpha] = v }
    suspend fun setThermal(v: Boolean) = context.store.edit { it[K.th] = v }
    suspend fun setThermalMode(v: Int) = context.store.edit { it[K.thMode] = v }
    suspend fun setAccent(v: Int) = context.store.edit { it[K.accent] = v }
    suspend fun setFontScale(v: Float) = context.store.edit { it[K.fontScale] = v }
    suspend fun setThermalIntensity(v: Float) = context.store.edit { it[K.thInt] = v }
}
