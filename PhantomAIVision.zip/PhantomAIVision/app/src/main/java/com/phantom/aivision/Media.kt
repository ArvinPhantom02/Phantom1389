package com.phantom.aivision

import android.content.Context
import android.graphics.*
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlin.math.max

fun loadBitmap(ctx: Context, uri: Uri, maxDim: Int = 1280): Bitmap? = runCatching {
    val cr = ctx.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (max(bounds.outWidth, bounds.outHeight) / sample > maxDim * 2) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        ?: return@runCatching null
    val orient = cr.openInputStream(uri)?.use {
        ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    } ?: ExifInterface.ORIENTATION_NORMAL
    val deg = when (orient) {
        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
        else -> 0f
    }
    if (deg == 0f) bmp
    else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
}.getOrNull()

fun videoDurationMs(ctx: Context, uri: Uri): Long = runCatching {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(ctx, uri)
        r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
    } finally { r.release() }
}.getOrDefault(0L)

fun videoFrameAt(ctx: Context, uri: Uri, ms: Long): Bitmap? = runCatching {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(ctx, uri)
        r.getFrameAtTime(ms * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
    } finally { r.release() }
}.getOrNull()

fun sampleBitmap(): Bitmap {
    val b = Bitmap.createBitmap(640, 480, Bitmap.Config.ARGB_8888)
    val c = Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.shader = LinearGradient(0f, 0f, 640f, 480f, 0xFF1B3A5C.toInt(), 0xFFF2C14E.toInt(), Shader.TileMode.CLAMP)
    c.drawRect(0f, 0f, 640f, 480f, p)
    p.shader = null
    p.color = 0xFFFFFFFF.toInt(); c.drawCircle(160f, 160f, 80f, p)
    p.color = 0xFF222222.toInt(); c.drawRect(300f, 200f, 560f, 420f, p)
    p.color = 0xFFD62828.toInt(); c.drawCircle(450f, 120f, 50f, p)
    return b
}
