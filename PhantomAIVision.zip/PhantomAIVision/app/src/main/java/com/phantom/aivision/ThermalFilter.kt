package com.phantom.aivision

import android.graphics.Bitmap

/** پردازش رنگ تصویر. هیچ اطلاعات اضافه‌ای از صحنه استخراج نمی‌کند. */
object ThermalFilter {
    private val thermalStops = listOf(
        0f to 0xFF000030.toInt(), 0.25f to 0xFF4B0082.toInt(), 0.5f to 0xFFD62828.toInt(),
        0.75f to 0xFFFFA500.toInt(), 1f to 0xFFFFFF99.toInt()
    )
    private val irStops = listOf(
        0f to 0xFF000000.toInt(), 0.5f to 0xFF7A0A0A.toInt(), 1f to 0xFFFFFFFF.toInt()
    )
    private val thermalLut = IntArray(256) { lerp(it / 255f, thermalStops) }
    private val irLut = IntArray(256) { lerp(it / 255f, irStops) }

    private fun lerp(t: Float, stops: List<Pair<Float, Int>>): Int {
        for (i in 1 until stops.size) {
            val (t1, c1) = stops[i]
            if (t <= t1) {
                val (t0, c0) = stops[i - 1]
                val f = ((t - t0) / (t1 - t0)).coerceIn(0f, 1f)
                fun ch(sh: Int) = (((c0 shr sh) and 0xFF) * (1 - f) + ((c1 shr sh) and 0xFF) * f).toInt()
                return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
            }
        }
        return stops.last().second
    }

    fun apply(src: Bitmap, mode: Int, intensity: Float): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val k = intensity.coerceIn(0f, 1f)
        val factor = 1f + 3f * k
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            if (mode == 3) {
                fun ct(v: Int) = (((v - 128) * factor) + 128).toInt().coerceIn(0, 255)
                px[i] = (0xFF shl 24) or (ct(r) shl 16) or (ct(g) shl 8) or ct(b)
                continue
            }
            val y = (0.299f * r + 0.587f * g + 0.114f * b).toInt().coerceIn(0, 255)
            val f = when (mode) {
                0 -> thermalLut[y]
                1 -> irLut[y]
                else -> (0xFF shl 24) or (y shl 16) or (y shl 8) or y
            }
            fun mix(o: Int, n: Int) = (o * (1 - k) + n * k).toInt().coerceIn(0, 255)
            px[i] = (0xFF shl 24) or
                (mix(r, (f shr 16) and 0xFF) shl 16) or
                (mix(g, (f shr 8) and 0xFF) shl 8) or
                mix(b, f and 0xFF)
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
}
