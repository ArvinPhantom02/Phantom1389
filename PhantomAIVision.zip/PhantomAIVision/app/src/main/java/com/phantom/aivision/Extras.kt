package com.phantom.aivision

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.phantom.aivision.data.AppSettings
import com.phantom.aivision.data.SettingsRepository
import com.phantom.aivision.ui.Accents
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

/** تشخیص زنده با دوربین گوشی روی صحنهٔ واقعی (نه ضبط صفحه). */
@Composable
fun LiveCameraDetection(s: AppSettings) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val detector = remember { runCatching { YoloDetector(ctx) }.getOrNull() }
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }
    var dets by remember { mutableStateOf<List<Detection>>(emptyList()) }
    val executor = remember { Executors.newSingleThreadExecutor() }
    val sens by rememberUpdatedState(s.sensitivity)
    val minS by rememberUpdatedState(s.minSize)

    DisposableEffect(Unit) {
        onDispose { executor.shutdown(); executor.awaitTermination(500, java.util.concurrent.TimeUnit.MILLISECONDS); detector?.close() }
    }

    if (detector == null) { Text(stringResource(R.string.model_missing)); return }
    if (!granted) { Text(stringResource(R.string.camera_denied)); return }

    Text(stringResource(R.string.camera_note), style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(8.dp))
    Box(Modifier.fillMaxWidth().aspectRatio(3f / 4f)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                val pv = PreviewView(c).apply { scaleType = PreviewView.ScaleType.FIT_CENTER }
                val fut = ProcessCameraProvider.getInstance(c)
                fut.addListener({
                    val provider = fut.get()
                    val preview = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
                    val analysis = ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                        .build()
                    analysis.setAnalyzer(executor) { proxy ->
                        try {
                            val bmp = proxy.toBitmap()
                            val rot = proxy.imageInfo.rotationDegrees
                            val img: Bitmap = if (rot != 0)
                                Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height,
                                    Matrix().apply { postRotate(rot.toFloat()) }, true)
                            else bmp
                            dets = detector.detect(img, sens, minS)
                        } catch (_: Throwable) {
                        } finally { proxy.close() }
                    }
                    provider.unbindAll()
                    provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                }, ContextCompat.getMainExecutor(c))
                pv
            },
            onRelease = { runCatching { ProcessCameraProvider.getInstance(ctx).get().unbindAll() } }
        )
        Canvas(Modifier.fillMaxSize()) {
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.WHITE; textSize = size.width / 22f
            }
            for (d in dets) {
                val l = d.box.left * size.width; val t = d.box.top * size.height
                val w = d.box.width() * size.width; val h = d.box.height() * size.height
                drawRect(Color.Red, Offset(l, t), Size(w, h), style = Stroke(width = 4f))
                drawIntoCanvas {
                    it.nativeCanvas.drawText("شخص ${(d.score * 100).toInt()}%", l + 6f, (t - 8f).coerceAtLeast(paint.textSize), paint)
                }
            }
        }
    }
}

@Composable
fun AppearanceScreen(s: AppSettings, repo: SettingsRepository) {
    val scope = rememberCoroutineScope()
    Text(stringResource(R.string.accent_color), style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Accents.forEachIndexed { i, c ->
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(c)
                    .border(if (i == s.accentIndex) 3.dp else 0.dp, Color.White, CircleShape)
                    .clickable { scope.launch { repo.setAccent(i) } }
            )
        }
    }
    Spacer(Modifier.height(16.dp))
    SliderRow(R.string.font_scale, s.fontScale, 0.85f..1.3f) { scope.launch { repo.setFontScale(it) } }
}
