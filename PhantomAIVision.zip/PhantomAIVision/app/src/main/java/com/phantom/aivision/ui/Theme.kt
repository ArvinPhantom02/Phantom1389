package com.phantom.aivision.ui

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Density

val Bg = Color(0xFF0B0B0F)
val Surface1 = Color(0xFF16161D)
val Accents = listOf(0xFFE53935, 0xFFFB8C00, 0xFF1E88E5, 0xFF43A047).map { Color(it) }

// فونت اختیاری: فایل را در app/src/main/assets/fonts/vazirmatn_regular.ttf بگذار
private const val FONT_PATH = "fonts/vazirmatn_regular.ttf"

@Composable
fun PhantomTheme(accentIndex: Int, fontScale: Float, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val family = remember {
        runCatching {
            android.graphics.Typeface.createFromAsset(ctx.assets, FONT_PATH) // اگر نبود خطا می‌دهد
            FontFamily(Font(FONT_PATH, ctx.assets))
        }.getOrDefault(FontFamily.Default)
    }
    val d = LocalDensity.current
    val base = Typography()
    fun TextStyle.v() = copy(fontFamily = family)
    val typo = Typography(
        headlineLarge = base.headlineLarge.v(), titleLarge = base.titleLarge.v(),
        titleMedium = base.titleMedium.v(), bodyLarge = base.bodyLarge.v(),
        bodyMedium = base.bodyMedium.v(), labelLarge = base.labelLarge.v()
    )
    CompositionLocalProvider(LocalDensity provides Density(d.density, d.fontScale * fontScale)) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = Accents[accentIndex.coerceIn(0, Accents.lastIndex)],
                background = Bg, surface = Surface1,
                onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
            ),
            typography = typo, content = content
        )
    }
}
