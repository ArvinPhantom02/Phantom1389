package com.phantom.aivision

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.*
import android.widget.*
import androidx.core.app.ServiceCompat
import com.phantom.aivision.data.AppSettings
import com.phantom.aivision.data.SettingsRepository
import kotlinx.coroutines.*
import kotlin.math.abs

/** ذره‌بین شناور: بزرگ‌نمایی ناحیهٔ وسط صفحه با MediaProjection رسمی اندروید. */
class MagnifierService : Service() {
    companion object {
        const val ACTION_START = "com.phantom.aivision.START"
        const val ACTION_STOP = "com.phantom.aivision.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "magnifier"
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var repo: SettingsRepository
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var bubble: TextView? = null
    private var panel: FrameLayout? = null
    private var imageView: ImageView? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelAttached = false
    private var bgThread: HandlerThread? = null
    private var bg: Handler? = null
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    @Volatile private var settings = AppSettings()
    @Volatile private var zoom = 2f
    @Volatile private var showing = false

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    private fun readData(i: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else i?.getParcelableExtra(EXTRA_DATA)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (running) return START_NOT_STICKY
        val code = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = readData(intent)
        if (code != Activity.RESULT_OK || data == null || !Settings.canDrawOverlays(this)) {
            stopSelf(); return START_NOT_STICKY
        }
        startAsForeground() // باید قبل از getMediaProjection فراخوانی شود
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        repo = SettingsRepository(applicationContext)
        bgThread = HandlerThread("mag-capture").also { it.start() }
        bg = Handler(bgThread!!.looper)

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)
        setupCapture()
        buildOverlay()
        scope.launch {
            repo.settings.collect { s -> settings = s; zoom = s.magnification; applyPanel() }
        }
        running = true
        bg?.post(loop)
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "ذره‌بین", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0, Intent(this, MagnifierService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("PHANTOM AI VISION")
            .setContentText("ذره‌بین شناور فعال است")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "توقف", stop
                ).build()
            ).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    @Suppress("DEPRECATION")
    private fun setupCapture() {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        val r = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        reader = r
        vDisplay = projection!!.createVirtualDisplay(
            "phantom-mag", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun buildOverlay() {
        // دکمهٔ شناور
        val b = TextView(this).apply {
            text = "🔍"; textSize = 22f; gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(0xE6E53935.toInt())
            }
        }
        val blp = lp(dp(56f), dp(56f)).apply { x = dp(8f); y = dp(200f) }
        attachDrag(b, b, blp) { togglePanel() }
        wm.addView(b, blp)
        bubble = b

        // پنجرهٔ ذره‌بین
        val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_XY }
        val frame = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(iv, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }
        fun btn(t: String, a: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 18f
            setPadding(dp(14f), dp(4f), dp(14f), dp(4f)); setOnClickListener { a() }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setBackgroundColor(0x99000000.toInt())
            addView(btn("−") { changeZoom(-0.5f) })
            addView(btn("+") { changeZoom(0.5f) })
            addView(btn("✕") { hidePanel() })
        }
        frame.addView(bar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.END))
        val plp = lp(dp(220f), dp(165f)).apply { x = dp(80f); y = dp(120f) }
        attachDrag(iv, frame, plp, null)
        panel = frame; imageView = iv; panelLp = plp
    }

    private fun attachDrag(touch: View, target: View, p: WindowManager.LayoutParams, onClick: (() -> Unit)?) {
        touch.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved) {
                            p.x = sx + dx; p.y = sy + dy
                            if (target.isAttachedToWindow) wm.updateViewLayout(target, p)
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) onClick?.invoke()
                }
                return true
            }
        })
    }

    private fun togglePanel() = if (showing) hidePanel() else showPanel()

    private fun showPanel() {
        if (!panelAttached) { wm.addView(panel, panelLp); panelAttached = true }
        showing = true
    }

    private fun hidePanel() {
        showing = false
        if (panelAttached) { runCatching { wm.removeView(panel) }; panelAttached = false }
    }

    private fun applyPanel() {
        val p = panelLp ?: return
        p.width = dp(settings.magSizeDp)
        p.height = (p.width * 0.75f).toInt()
        panel?.alpha = settings.magAlpha
        if (panelAttached) wm.updateViewLayout(panel, p)
    }

    private fun changeZoom(d: Float) {
        val z = (zoom + d).coerceIn(1f, 5f)
        zoom = z
        scope.launch { repo.setMagnification(z) }
    }

    private val loop = object : Runnable {
        override fun run() {
            try { if (showing) grab() } catch (_: Throwable) {}
            bg?.postDelayed(this, 120) // حدود ۸ فریم بر ثانیه برای صرفه‌جویی در باتری
        }
    }

    private fun grab() {
        val img = try { reader?.acquireLatestImage() } catch (_: Exception) { null } ?: return
        try {
            val plane = img.planes[0]
            val rowPixels = plane.rowStride / plane.pixelStride
            val full = Bitmap.createBitmap(rowPixels, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            val s = settings
            val lp = panelLp ?: return
            val outW = lp.width.coerceAtLeast(64)
            val outH = lp.height.coerceAtLeast(48)
            val z = zoom
            val cw = (outW / z).toInt().coerceIn(16, img.width)
            val ch = (outH / z).toInt().coerceIn(16, img.height)
            val crop = Bitmap.createBitmap(full, (img.width - cw) / 2, (img.height - ch) / 2, cw, ch)
            val scaled = Bitmap.createScaledBitmap(crop, outW, outH, true)
            if (crop !== scaled) crop.recycle()
            full.recycle()
            val result = if (s.thermalEnabled)
                ThermalFilter.apply(scaled, s.thermalMode, s.thermalIntensity).also { scaled.recycle() }
            else scaled
            main.post { imageView?.setImageBitmap(result) }
        } finally {
            img.close()
        }
    }

    override fun onDestroy() {
        running = false
        scope.cancel()
        bg?.removeCallbacksAndMessages(null)
        bgThread?.quitSafely()
        runCatching { vDisplay?.release() }
        runCatching { reader?.close() }
        runCatching { projection?.stop() }
        if (::wm.isInitialized) {
            runCatching { if (panelAttached) wm.removeView(panel) }
            runCatching { bubble?.let { wm.removeView(it) } }
        }
        super.onDestroy()
    }
}
