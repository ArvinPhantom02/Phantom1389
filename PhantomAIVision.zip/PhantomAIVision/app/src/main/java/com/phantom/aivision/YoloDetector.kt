package com.phantom.aivision

import android.content.Context
import android.graphics.*
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

data class Detection(val box: RectF, val score: Float) // مختصات نرمال‌شده 0..1

/**
 * شناسایی کلاس «شخص» (index 0 در COCO) با خروجی YOLOv8 TFLite.
 * اگر فایل مدل نباشد، سازنده خطا می‌دهد و هیچ نتیجهٔ ساختگی تولید نمی‌شود.
 */
class YoloDetector(context: Context) : AutoCloseable {
    companion object {
        const val MODEL_FILE = "yolov8n_float32.tflite"
        fun isAvailable(context: Context) =
            context.assets.list("")?.contains(MODEL_FILE) == true
    }

    private val interpreter: Interpreter
    private val inW: Int
    private val inH: Int
    private val d1: Int
    private val d2: Int

    init {
        val fd = context.assets.openFd(MODEL_FILE)
        val buf = FileInputStream(fd.fileDescriptor).channel
            .map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
        interpreter = Interpreter(buf, Interpreter.Options().setNumThreads(4))
        val ins = interpreter.getInputTensor(0).shape() // [1,H,W,3]
        inH = ins[1]; inW = ins[2]
        val outs = interpreter.getOutputTensor(0).shape() // [1,84,N] یا [1,N,84]
        d1 = outs[1]; d2 = outs[2]
    }

    fun detect(bitmap: Bitmap, conf: Float, minHeight: Float): List<Detection> {
        val scaled = Bitmap.createScaledBitmap(bitmap, inW, inH, true)
        val px = IntArray(inW * inH)
        scaled.getPixels(px, 0, inW, 0, 0, inW, inH)
        if (scaled !== bitmap) scaled.recycle()
        val input = ByteBuffer.allocateDirect(4 * inW * inH * 3).order(ByteOrder.nativeOrder())
        for (p in px) {
            input.putFloat(((p shr 16) and 0xFF) / 255f)
            input.putFloat(((p shr 8) and 0xFF) / 255f)
            input.putFloat((p and 0xFF) / 255f)
        }
        input.rewind()

        val out = Array(1) { Array(d1) { FloatArray(d2) } }
        interpreter.run(input, out)

        val channelFirst = d1 < d2
        val n = if (channelFirst) d2 else d1
        fun v(f: Int, i: Int) = if (channelFirst) out[0][f][i] else out[0][i][f]

        val cands = ArrayList<Detection>()
        for (i in 0 until n) {
            val score = v(4, i)
            if (score < conf) continue
            var cx = v(0, i); var cy = v(1, i); var w = v(2, i); var h = v(3, i)
            if (cx > 2f || w > 2f || h > 2f) { cx /= inW; w /= inW; cy /= inH; h /= inH }
            if (h < minHeight) continue
            val box = RectF(
                (cx - w / 2).coerceIn(0f, 1f), (cy - h / 2).coerceIn(0f, 1f),
                (cx + w / 2).coerceIn(0f, 1f), (cy + h / 2).coerceIn(0f, 1f)
            )
            if (box.width() <= 0f || box.height() <= 0f) continue
            cands.add(Detection(box, score))
        }
        return nms(cands, 0.45f)
    }

    private fun nms(list: List<Detection>, iouThr: Float): List<Detection> {
        val sorted = list.sortedByDescending { it.score }
        val keep = ArrayList<Detection>()
        for (d in sorted) if (keep.none { iou(it.box, d.box) > iouThr }) keep.add(d)
        return keep
    }

    private fun iou(a: RectF, b: RectF): Float {
        val l = maxOf(a.left, b.left); val t = maxOf(a.top, b.top)
        val r = minOf(a.right, b.right); val bt = minOf(a.bottom, b.bottom)
        val inter = maxOf(0f, r - l) * maxOf(0f, bt - t)
        val u = a.width() * a.height() + b.width() * b.height() - inter
        return if (u <= 0f) 0f else inter / u
    }

    override fun close() = interpreter.close()
}

object DetectionRenderer {
    fun draw(src: Bitmap, dets: List<Detection>): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(out)
        val sw = (out.width / 300f).coerceAtLeast(2f)
        val boxP = Paint().apply { color = Color.RED; style = Paint.Style.STROKE; strokeWidth = sw }
        val bgP = Paint().apply { color = Color.RED }
        val txtP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = sw * 7f }
        for (d in dets) {
            val r = RectF(d.box.left * out.width, d.box.top * out.height,
                d.box.right * out.width, d.box.bottom * out.height)
            c.drawRect(r, boxP)
            val label = "شخص ${(d.score * 100).toInt()}%"
            val tw = txtP.measureText(label)
            val th = txtP.textSize * 1.4f
            val top = (r.top - th).coerceAtLeast(0f)
            c.drawRect(r.left, top, r.left + tw + sw * 4, top + th, bgP)
            c.drawText(label, r.left + sw * 2, top + th * 0.75f, txtP)
        }
        return out
    }
}
