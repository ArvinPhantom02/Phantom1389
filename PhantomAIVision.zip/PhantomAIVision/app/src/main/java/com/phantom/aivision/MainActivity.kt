package com.phantom.aivision

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.phantom.aivision.data.AppSettings
import com.phantom.aivision.data.SettingsRepository
import com.phantom.aivision.ui.PhantomTheme
import kotlinx.coroutines.launch

enum class Screen(val titleRes: Int, val icon: ImageVector) {
    Home(R.string.menu_home, Icons.Filled.Home),
    Detection(R.string.menu_detection, Icons.Filled.CenterFocusStrong),
    Magnifier(R.string.menu_magnifier, Icons.Filled.ZoomIn),
    Thermal(R.string.menu_thermal, Icons.Filled.Thermostat),
    Ai(R.string.menu_ai, Icons.Filled.Memory),
    Appearance(R.string.menu_appearance, Icons.Filled.Palette),
    Permissions(R.string.menu_permissions, Icons.Filled.Security),
    Guide(R.string.menu_guide, Icons.Filled.MenuBook),
    About(R.string.menu_about, Icons.Filled.Info)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val repo = remember { SettingsRepository(applicationContext) }
            val s by repo.settings.collectAsState(initial = AppSettings())
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                PhantomTheme(s.accentIndex, s.fontScale) { PhantomApp() }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhantomApp() {
    val ctx = LocalContext.current
    val repo = remember { SettingsRepository(ctx) }
    val s by repo.settings.collectAsState(initial = AppSettings())
    val scope = rememberCoroutineScope()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    var current by remember { mutableStateOf(Screen.Home) }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Spacer(Modifier.height(16.dp))
                Text(stringResource(R.string.app_name), color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(16.dp))
                Screen.values().forEach { sc ->
                    NavigationDrawerItem(
                        label = { Text(stringResource(sc.titleRes)) },
                        icon = { Icon(sc.icon, null) },
                        selected = sc == current,
                        onClick = { current = sc; scope.launch { drawer.close() } },
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(topBar = {
            TopAppBar(
                title = { Text(stringResource(current.titleRes)) },
                navigationIcon = {
                    IconButton(onClick = { scope.launch { drawer.open() } }) { Icon(Icons.Filled.Menu, null) }
                }
            )
        }) { pad ->
            Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState())) {
                when (current) {
                    Screen.Home -> Text(stringResource(R.string.app_name), color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.headlineLarge)
                    Screen.Detection -> DetectionScreen(s, repo)
                    Screen.Magnifier -> MagnifierScreen(s, repo)
                    Screen.Thermal -> ThermalScreen(s, repo)
                    Screen.Ai -> AiSettingsScreen(s, repo)
                    Screen.Permissions -> PermissionsScreen()
                    Screen.Guide -> Text(stringResource(R.string.guide_text))
                    Screen.About -> Text(stringResource(R.string.about_text))
                    Screen.Appearance -> AppearanceScreen(s, repo)
                }
            }
        }
    }
}

@Composable
fun SwitchRow(label: Int, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween) {
        Text(stringResource(label)); Switch(value, onChange)
    }
}

@Composable
fun SliderRow(label: Int, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    var v by remember(value) { mutableStateOf(value) }
    Column(Modifier.padding(vertical = 8.dp)) {
        Text(stringResource(label) + ": " + "%.2f".format(v))
        Slider(v, { v = it }, valueRange = range, onValueChangeFinished = { onChange(v) })
    }
}
