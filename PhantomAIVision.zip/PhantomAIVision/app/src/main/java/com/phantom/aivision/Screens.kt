package com.phantom.aivision

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.phantom.aivision.data.AppSettings
import com.phantom.aivision.data.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun DetectionScreen(s: AppSettings, repo: SettingsRepository) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val detector = remember { runCatching { YoloDetector(ctx) }.getOrNull() }
    DisposableEffect(Unit) { onDispose { detector?.close() } }

    var source by remember { mutableStateOf<Bitmap?>(null) }
    var result by remember { mutableStateOf<Bitmap?>(null) }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var duration by remember { mutableStateOf(0L) }
    var pos by remember { mutableStateOf(0f) }
    var info by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            result = null; info = ""
            val isVideo = (ctx.contentResolver.getType(uri) ?: "").startsWith("video")
            withContext(Dispatchers.IO) {
                if (isVideo) {
                    duration = videoDurationMs(ctx, uri); pos = 0f
                    source = videoFrameAt(ctx, uri, 0)
                } else {
                    duration = 0L
                    source = loadBitmap(ctx, uri)
                }
            }
            videoUri = if (isVideo) uri else null
        }
    }

    SwitchRow(R.string.detection_enabled, s.detectionEnabled) { scope.launch { repo.setDetection(it) } }
    SliderRow(R.string.sensitivity, s.sensitivity, 0.1f..0.95f) { scope.launch { repo.setSensitivity(it) } }
    SliderRow(R.string.min_size, s.minSize, 0.01f..0.5f) { scope.launch { repo.setMinSize(it) } }
    Text(stringResource(R.string.detect_scope), style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(8.dp))
    if (detector == null) Text(stringResource(R.string.model_missing), color = MaterialTheme.colorScheme.primary)

    Button(onClick = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
    }) { Text(stringResource(R.string.pick_media)) }

    var live by remember { mutableStateOf(false) }
    OutlinedButton(enabled = s.detectionEnabled, onClick = { live = !live }) {
        Text(stringResource(if (live) R.string.stop_camera else R.string.live_camera))
    }
    if (live) LiveCameraDetection(s)

    val uri = videoUri
    if (uri != null && duration > 0) {
        Text(stringResource(R.string.video_pos))
        Slider(
            value = pos, onValueChange = { pos = it }, valueRange = 0f..duration.toFloat(),
            onValueChangeFinished = {
                scope.launch {
                    result = null
                    source = withContext(Dispatchers.IO) { videoFrameAt(ctx, uri, pos.toLong()) }
                }
            }
        )
    }

    val src = source
    if (src != null) {
        Spacer(Modifier.height(8.dp))
        Button(
            enabled = s.detectionEnabled && detector != null && !busy,
            onClick = {
                busy = true
                scope.launch {
                    val dets = withContext(Dispatchers.Default) {
                        detector!!.detect(src, s.sensitivity, s.minSize)
                    }
                    result = withContext(Dispatchers.Default) { DetectionRenderer.draw(src, dets) }
                    info = if (dets.isEmpty()) ctx.getString(R.string.no_detection)
                    else ctx.getString(R.string.n_detected, dets.size)
                    busy = false
                }
            }
        ) { Text(stringResource(R.string.analyze)) }
        if (!s.detectionEnabled) Text(stringResource(R.string.enable_detection_hint))
        if (info.isNotEmpty()) Text(info)
        Image(
            bitmap = (result ?: src).asImageBitmap(), contentDescription = null,
            modifier = Modifier.fillMaxWidth(), contentScale = ContentScale.Fit
        )
    }
}

@Composable
fun MagnifierScreen(s: AppSettings, repo: SettingsRepository) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var running by remember { mutableStateOf(MagnifierService.running) }

    val capture = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == Activity.RESULT_OK && data != null) {
            val i = Intent(ctx, MagnifierService::class.java)
                .setAction(MagnifierService.ACTION_START)
                .putExtra(MagnifierService.EXTRA_CODE, r.resultCode)
                .putExtra(MagnifierService.EXTRA_DATA, data)
            ContextCompat.startForegroundService(ctx, i)
            running = true
        }
    }
    fun requestCapture() {
        val mpm = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        capture.launch(mpm.createScreenCaptureIntent())
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        requestCapture() // اعلان اجباری نیست؛ سرویس در هر حال شروع می‌شود
    }

    SliderRow(R.string.magnification, s.magnification, 1f..5f) { scope.launch { repo.setMagnification(it) } }
    SliderRow(R.string.mag_size, s.magSizeDp, 140f..360f) { scope.launch { repo.setMagSize(it) } }
    SliderRow(R.string.mag_alpha, s.magAlpha, 0.3f..1f) { scope.launch { repo.setMagAlpha(it) } }
    Text(stringResource(R.string.mag_note), style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(12.dp))

    if (!running && !MagnifierService.running) {
        Button(onClick = {
            if (!Settings.canDrawOverlays(ctx)) {
                Toast.makeText(ctx, R.string.overlay_needed, Toast.LENGTH_LONG).show()
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                )
            } else if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            else requestCapture()
        }) { Text(stringResource(R.string.start_magnifier)) }
    } else {
        OutlinedButton(onClick = {
            ctx.startService(Intent(ctx, MagnifierService::class.java).setAction(MagnifierService.ACTION_STOP))
            running = false
        }) { Text(stringResource(R.string.stop_magnifier)) }
    }
}

@Composable
fun ThermalScreen(s: AppSettings, repo: SettingsRepository) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var picked by remember { mutableStateOf<Bitmap?>(null) }
    val sample = remember { sampleBitmap() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch { picked = withContext(Dispatchers.IO) { loadBitmap(ctx, uri, 640) } }
    }

    SwitchRow(R.string.thermal_enabled, s.thermalEnabled) { scope.launch { repo.setThermal(it) } }
    SliderRow(R.string.thermal_intensity, s.thermalIntensity, 0f..1f) { scope.launch { repo.setThermalIntensity(it) } }
    Text(stringResource(R.string.thermal_mode))
    listOf(R.string.mode_thermal, R.string.mode_infrared, R.string.mode_gray, R.string.mode_contrast)
        .forEachIndexed { i, r ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(s.thermalMode == i, { scope.launch { repo.setThermalMode(i) } })
                Text(stringResource(r))
            }
        }
    Text(stringResource(R.string.thermal_note), style = MaterialTheme.typography.bodyMedium)
    Text(stringResource(R.string.sample_note), style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(8.dp))
    Button(onClick = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }) { Text(stringResource(R.string.pick_image)) }

    val base = picked ?: sample
    val shown = remember(base, s.thermalEnabled, s.thermalMode, s.thermalIntensity) {
        if (s.thermalEnabled) ThermalFilter.apply(base, s.thermalMode, s.thermalIntensity) else base
    }
    Spacer(Modifier.height(8.dp))
    Image(
        bitmap = shown.asImageBitmap(), contentDescription = null,
        modifier = Modifier.fillMaxWidth(), contentScale = ContentScale.Fit
    )
}

@Composable
fun AiSettingsScreen(s: AppSettings, repo: SettingsRepository) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    Text(stringResource(R.string.model_status), style = MaterialTheme.typography.titleMedium)
    Text(
        if (YoloDetector.isAvailable(ctx)) stringResource(R.string.model_ok)
        else stringResource(R.string.model_missing)
    )
    Spacer(Modifier.height(8.dp))
    SliderRow(R.string.sensitivity, s.sensitivity, 0.1f..0.95f) { scope.launch { repo.setSensitivity(it) } }
    SliderRow(R.string.min_size, s.minSize, 0.01f..0.5f) { scope.launch { repo.setMinSize(it) } }
}

@Composable
fun PermissionsScreen() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    val overlay = remember(tick) { Settings.canDrawOverlays(ctx) }
    val notif = remember(tick) {
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    PermRow(R.string.perm_overlay, overlay) {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
    }
    PermRow(R.string.perm_notif, notif) {
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    Text(stringResource(R.string.perm_capture), style = MaterialTheme.typography.titleMedium)
    Text(stringResource(R.string.perm_capture_note), style = MaterialTheme.typography.bodyMedium)
}

@Composable
private fun PermRow(label: Int, granted: Boolean, onGrant: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(stringResource(label))
            Text(stringResource(if (granted) R.string.granted else R.string.not_granted),
                style = MaterialTheme.typography.bodyMedium)
        }
        if (!granted) Button(onClick = onGrant) { Text(stringResource(R.string.grant)) }
    }
}
