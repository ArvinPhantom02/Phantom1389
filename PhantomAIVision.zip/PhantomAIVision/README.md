# PHANTOM AI VISION

## فایل‌هایی که باید خودت اضافه کنی
1. فونت: `app/src/main/assets/fonts/vazirmatn_regular.ttf` (اختیاری؛ از github.com/rastikerdar/vazirmatn. بدون آن فونت پیش‌فرض اندروید استفاده می‌شود)
2. مدل: `app/src/main/assets/yolov8n_float32.tflite`
   ```
   pip install ultralytics
   yolo export model=yolov8n.pt format=tflite imgsz=640
   ```
   فایل `yolov8n_saved_model/yolov8n_float32.tflite` را کپی کن. (لایسنس Ultralytics AGPL-3.0 است؛ برای انتشار عمومی بررسی کن.)
   مدل باید خروجی [1,84,N] داشته باشد؛ کلاس شخص (index 0) استفاده می‌شود.

## ساخت APK
1. Android Studio (Koala+) ← Open ← پوشهٔ پروژه ← Sync.
2. Build ← Build APK(s) ← فایل در `app/build/outputs/apk/debug/app-debug.apk`.
3. روی گوشی: Developer options ← USB debugging ← با کابل Run بزن، یا APK را منتقل و نصب کن (نصب از منبع ناشناس).

## وابستگی‌ها
Compose Material3، DataStore، TensorFlow Lite 2.14، core-ktx. minSdk 26، targetSdk 34.

## مجوزها
- SYSTEM_ALERT_WINDOW (دستی از تنظیمات)، POST_NOTIFICATIONS (اندروید ۱۳+)
- FOREGROUND_SERVICE_MEDIA_PROJECTION + دیالوگ رسمی ضبط صفحه در هر شروع

## محدودیت‌ها
- فیلتر حرارتی روی ذره‌بین و پیش‌نمایش اعمال می‌شود، نه کل صفحهٔ سیستم.
- تشخیص روی تصویر/ویدیوی انتخابی انجام می‌شود، نه روی صفحهٔ زندهٔ بازی.
- ذره‌بین ناحیهٔ وسط صفحه را بزرگ می‌کند؛ برنامه‌های دارای FLAG_SECURE سیاه ضبط می‌شوند.

## دوربین زنده
در «تشخیص کاراکترها» با روشن‌کردن تشخیص، دکمهٔ «دوربین زنده» دوربین پشت گوشی را برای شناسایی آدم‌ها در صحنهٔ واقعی باز می‌کند.

## ساخت بدون کامپیوتر
فایل `.github/workflows/build.yml` در GitHub Actions مدل را می‌سازد و APK را تحویل می‌دهد (Actions ← Build APK ← Run workflow ← Artifacts).
